package com.example.googlemaptut3;

public class LocationManager {
}
